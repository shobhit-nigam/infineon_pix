i = int(input("enter a number less than 10:\n"))
assert (i<10), "should have entered a value less than 10"

print("code continues")
