lista = [33, 76, 90, 12, 54, 67]
index = 0


age = int(input("enter the index here: \n"))
if age < 18:
    raise Exception("age should not be less than 18")
print("all good")


print("code continues")
