lista = [33, 76, 90, 12, 54, 67]

index = int(input("enter the index here: \n"))

print(lista[index])
