
data = "hi"
ia = 32

stra = "data is data , val is ia"
print(stra)

strb = "data is {data} , val is {ia}"
print(strb)

strc = f"data is {data} , val is {ia}"
print(strc)
