# self

class sample:
    """our fisrt class"""

    data_1 = 287
    data_2 = "monday"

    def funca(self):
        print("hello world")

obja = sample()
objb = sample()

print(obja.data_1)

obja.funca()
# sample.funca(obja)
