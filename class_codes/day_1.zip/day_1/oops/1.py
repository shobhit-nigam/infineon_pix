# all data & code is object

data = 10
print(type(data))
