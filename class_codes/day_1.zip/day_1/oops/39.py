# polymorphism

print("hello" + "hi")

def x(la):
    print("hi")

def x():
    print("hello")

x(100)
