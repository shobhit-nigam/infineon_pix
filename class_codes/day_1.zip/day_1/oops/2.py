# all data & code is object

class sample:
    """our fisrt class"""

    data_a = 287

    def funca(self):
        print("hello world")
        return data_a

obja = sample()

print(obja.data_a)
