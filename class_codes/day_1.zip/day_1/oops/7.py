# self
# self is not a keyword

class sample:
    """our fisrt class"""

    data_1 = 287
    data_2 = "monday"

    def funca(xxx):
        print("hello world")

obja = sample()
objb = sample()

obja.funca()
# sample.funca(obja)

objb.funca()
# sample.funca(objb)
