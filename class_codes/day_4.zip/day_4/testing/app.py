def add(la, lb):
    return la + lb

dataa = 100
datab = 200
