lista = [10, 20, 20]

assert sum(lista) == 60, "expecting 60"
